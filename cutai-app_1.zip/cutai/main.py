import os
import uuid
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import aiofiles
from dotenv import load_dotenv

load_dotenv()

from video_processor import VideoProcessor

# ── In-memory job store ──────────────────────────────────────────────────────
jobs: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    for d in ("temp", "uploads", "outputs"):
        os.makedirs(d, exist_ok=True)
    yield


app = FastAPI(title="cut.ai", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return FileResponse("frontend/index.html")


@app.post("/api/upload")
async def upload_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    silence_threshold: float = Form(default=0.4),
    transition: str = Form(default="fade"),
):
    allowed = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
    ext = Path(file.filename or "video.mp4").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Supported: {', '.join(allowed)}")

    job_id = str(uuid.uuid4())
    upload_path = f"uploads/{job_id}{ext}"

    async with aiofiles.open(upload_path, "wb") as f:
        while chunk := await file.read(1024 * 1024):
            await f.write(chunk)

    jobs[job_id] = {
        "status": "processing",
        "progress": 0,
        "step": "Queued",
        "detail": "",
        "error": None,
        "output_file": None,
        "stats": {},
        "filename": file.filename,
    }

    settings = {
        "silence_threshold": silence_threshold,
        "transition": transition,
    }

    background_tasks.add_task(run_processing, job_id, upload_path, settings)
    return {"job_id": job_id}


@app.get("/api/job/{job_id}")
async def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return {k: v for k, v in jobs[job_id].items() if k != "output_file"}


@app.get("/api/download/{job_id}")
async def download_video(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    job = jobs[job_id]
    if job["status"] != "done":
        raise HTTPException(400, "Video not ready yet")
    if not job["output_file"] or not os.path.exists(job["output_file"]):
        raise HTTPException(500, "Output file missing")
    return FileResponse(
        job["output_file"],
        media_type="video/mp4",
        filename="cutai_edited.mp4",
    )


@app.get("/api/preview/{job_id}")
async def preview_video(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    job = jobs[job_id]
    if job["status"] != "done" or not job["output_file"]:
        raise HTTPException(400, "Not ready")
    return FileResponse(job["output_file"], media_type="video/mp4")


# ── Background task ───────────────────────────────────────────────────────────

async def run_processing(job_id: str, input_path: str, settings: dict):
    processor = VideoProcessor(job_id, jobs)
    await processor.process(input_path, settings)
    try:
        os.remove(input_path)
    except Exception:
        pass


# ── Serve frontend ────────────────────────────────────────────────────────────

app.mount("/static", StaticFiles(directory="frontend"), name="static")

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    uvicorn.run("main:app", host=host, port=port, reload=True)
