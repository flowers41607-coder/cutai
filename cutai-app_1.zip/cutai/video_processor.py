import os
import subprocess
import json
import asyncio
import shutil

try:
    from pydub import AudioSegment
    from pydub.silence import detect_nonsilent
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False


def ffmpeg_available():
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


class VideoProcessor:
    def __init__(self, job_id: str, jobs: dict):
        self.job_id = job_id
        self.jobs = jobs
        self.temp_dir = f"temp/{job_id}"
        os.makedirs(self.temp_dir, exist_ok=True)

    def update(self, progress: int, step: str, detail: str = ""):
        self.jobs[self.job_id].update({
            "progress": progress,
            "step": step,
            "detail": detail,
        })

    async def process(self, input_path: str, settings: dict):
        try:
            if not ffmpeg_available():
                raise RuntimeError(
                    "FFmpeg is not installed. "
                    "Install it from https://ffmpeg.org/download.html"
                )

            # Settings
            silence_threshold_s = float(settings.get("silence_threshold", 0.4))
            transition = settings.get("transition", "fade")  # "fade" or "cut"

            final_path = f"outputs/{self.job_id}_final.mp4"
            os.makedirs("outputs", exist_ok=True)

            # ── 1. Probe original ─────────────────────────────────────────
            self.update(8, "Reading video", "Checking format, duration and streams")
            probe = self._probe(input_path)
            original_duration = float(probe.get("format", {}).get("duration", 0))
            await asyncio.sleep(0.3)

            # ── 2. Extract audio ──────────────────────────────────────────
            self.update(22, "Analyzing audio", "Scanning for dead space, pauses and retakes")
            audio_path = f"{self.temp_dir}/audio.wav"
            await asyncio.to_thread(self._extract_audio, input_path, audio_path)

            # ── 3. Detect speech segments ─────────────────────────────────
            self.update(40, "Finding cuts", "Detecting where speech starts and stops")
            segments = await asyncio.to_thread(
                self._detect_segments, audio_path, silence_threshold_s
            )

            if not segments:
                # Nothing to cut — just re-encode cleanly
                await asyncio.to_thread(self._encode_only, input_path, final_path)
                self._finish(original_duration, original_duration, 0, 0.0, final_path)
                return

            # ── 4. Cut and join ───────────────────────────────────────────
            self.update(60, "Cutting and joining", f"Removing gaps, joining {len(segments)} segments smoothly")
            stats = await asyncio.to_thread(
                self._cut_and_join,
                input_path, final_path, segments, transition, original_duration
            )

            # ── 5. Done ───────────────────────────────────────────────────
            self.update(93, "Finishing up", "Optimising for web playback")
            final_probe = self._probe(final_path)
            final_duration = float(final_probe.get("format", {}).get("duration", 0))
            await asyncio.sleep(0.3)

            self._finish(original_duration, final_duration, stats["cuts"], stats["removed_seconds"], final_path)

        except Exception as e:
            self.jobs[self.job_id].update({
                "status": "error",
                "step": "Error",
                "error": str(e),
            })
        finally:
            shutil.rmtree(self.temp_dir, ignore_errors=True)

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _finish(self, orig, final, cuts, removed, path):
        self.jobs[self.job_id].update({
            "status": "done",
            "progress": 100,
            "step": "Done",
            "output_file": path,
            "stats": {
                "original_duration": round(orig, 1),
                "final_duration": round(final, 1),
                "removed_seconds": round(removed, 1),
                "cuts": cuts,
            },
        })

    def _probe(self, path: str) -> dict:
        cmd = [
            "ffprobe", "-v", "quiet",
            "-print_format", "json",
            "-show_format", "-show_streams", path,
        ]
        r = subprocess.run(cmd, capture_output=True, text=True)
        try:
            return json.loads(r.stdout)
        except Exception:
            return {}

    def _extract_audio(self, video_path: str, audio_path: str):
        subprocess.run(
            ["ffmpeg", "-i", video_path, "-ar", "16000", "-ac", "1", "-y", audio_path],
            capture_output=True, check=True,
        )

    def _detect_segments(self, audio_path: str, silence_threshold_s: float) -> list:
        """
        Returns list of [start_ms, end_ms] for every non-silent region.
        A 'retake' is naturally caught because the person pauses before restarting —
        that pause is a silence gap we can cut.
        """
        if not PYDUB_AVAILABLE:
            return []

        audio = AudioSegment.from_wav(audio_path)
        total_ms = len(audio)

        # Dynamic threshold: 16 dB below average loudness of the clip
        thresh = audio.dBFS - 16
        min_silence_ms = int(silence_threshold_s * 1000)

        nonsilent = detect_nonsilent(
            audio,
            min_silence_len=min_silence_ms,
            silence_thresh=thresh,
            seek_step=10,
        )

        if not nonsilent:
            return []

        # Pad each segment by 80 ms so we don't clip the first/last syllable
        padding = 80
        padded = [
            [max(0, s - padding), min(total_ms, e + padding)]
            for s, e in nonsilent
        ]

        # Merge segments that now overlap after padding
        merged = []
        for seg in padded:
            if merged and seg[0] <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], seg[1])
            else:
                merged.append(seg)

        return merged

    def _cut_and_join(
        self,
        input_path: str,
        output_path: str,
        segments: list,
        transition: str,
        original_duration: float,
    ) -> dict:
        """
        Trim each kept segment and concatenate.
        - Audio: always apply a 70 ms fade in/out at boundaries → no pops
        - Video: apply the same 70 ms fade if transition == "fade" → smooth dissolve
        """
        n = len(segments)
        fade = 0.07  # 70 ms

        fv, fa = [], []
        for i, (s_ms, e_ms) in enumerate(segments):
            s = s_ms / 1000.0
            e = e_ms / 1000.0
            dur = e - s

            # --- Video ---
            v = f"[0:v]trim={s:.4f}:{e:.4f},setpts=PTS-STARTPTS"
            if transition == "fade" and dur > fade * 3:
                v += (
                    f",fade=t=in:st=0:d={fade}"
                    f",fade=t=out:st={max(0, dur - fade):.4f}:d={fade}"
                )
            fv.append(v + f"[v{i}]")

            # --- Audio (always faded to prevent pops at cut points) ---
            a = f"[0:a]atrim={s:.4f}:{e:.4f},asetpts=PTS-STARTPTS"
            if dur > fade * 3:
                a += (
                    f",afade=t=in:st=0:d={fade}"
                    f",afade=t=out:st={max(0, dur - fade):.4f}:d={fade}"
                )
            fa.append(a + f"[a{i}]")

        vc = "".join(f"[v{i}]" for i in range(n))
        ac = "".join(f"[a{i}]" for i in range(n))

        fc = (
            ";".join(fv) + ";" +
            ";".join(fa) + ";" +
            f"{vc}concat=n={n}:v=1:a=0[outv];" +
            f"{ac}concat=n={n}:v=0:a=1[outa]"
        )

        cmd = [
            "ffmpeg", "-i", input_path,
            "-filter_complex", fc,
            "-map", "[outv]", "-map", "[outa]",
            "-c:v", "libx264", "-preset", "fast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart",
            "-y", output_path,
        ]

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

        if result.returncode != 0:
            # Fallback: plain cut, no fades
            self._plain_cut(input_path, output_path, segments)

        kept_ms = sum(e - s for s, e in segments)
        removed_s = max(0.0, original_duration - kept_ms / 1000.0)

        return {
            "cuts": n,
            "removed_seconds": round(removed_s, 1),
        }

    def _plain_cut(self, input_path: str, output_path: str, segments: list):
        n = len(segments)
        fv = ";".join(
            f"[0:v]trim={s/1000:.3f}:{e/1000:.3f},setpts=PTS-STARTPTS[v{i}]"
            for i, (s, e) in enumerate(segments)
        )
        fa = ";".join(
            f"[0:a]atrim={s/1000:.3f}:{e/1000:.3f},asetpts=PTS-STARTPTS[a{i}]"
            for i, (s, e) in enumerate(segments)
        )
        vc = "".join(f"[v{i}]" for i in range(n))
        ac = "".join(f"[a{i}]" for i in range(n))
        fc = f"{fv};{fa};{vc}concat=n={n}:v=1:a=0[outv];{ac}concat=n={n}:v=0:a=1[outa]"
        cmd = [
            "ffmpeg", "-i", input_path,
            "-filter_complex", fc,
            "-map", "[outv]", "-map", "[outa]",
            "-c:v", "libx264", "-preset", "fast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart",
            "-y", output_path,
        ]
        subprocess.run(cmd, capture_output=True, timeout=600)

    def _encode_only(self, input_path: str, output_path: str):
        cmd = [
            "ffmpeg", "-i", input_path,
            "-c:v", "libx264", "-preset", "fast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart",
            "-y", output_path,
        ]
        subprocess.run(cmd, capture_output=True, timeout=600, check=True)
