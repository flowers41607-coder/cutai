# cut.ai

Drop raw footage in. Get a clean, edited video out.

The app does exactly three things:
1. **Removes dead space** — silence gaps, pauses, awkward moments
2. **Removes retakes** — the natural pause before a retake gets cut
3. **Smooth transitions** — 70ms audio & video fade at every cut point so nothing feels jarring

No captions. No overlays. No fluff. Just clean cuts.

---

## Requirements

- **Python 3.10+**
- **FFmpeg** installed and on your PATH

That's it. No API keys needed.

---

## Install FFmpeg

**Mac:**
```bash
brew install ffmpeg
```

**Windows:**
Download from https://ffmpeg.org/download.html → add to PATH.
Verify: `ffmpeg -version` in your terminal.

**Linux:**
```bash
sudo apt update && sudo apt install ffmpeg
```

---

## Setup

```bash
# 1. Unzip and enter the folder
cd cutai

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Mac / Linux
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run
python main.py
```

Open your browser at **http://localhost:8000**

---

## How it works

1. Upload any MP4, MOV, AVI or MKV file
2. Set silence sensitivity (how long a pause must be before it gets cut)
3. Toggle smooth transitions on or off
4. Hit **Auto-edit** — the backend:
   - Extracts audio and runs silence detection (`pydub`)
   - Identifies every non-silent region with 80 ms of padding
   - Cuts all silent gaps using FFmpeg's `filter_complex`
   - Applies 70 ms audio & video fades at each cut boundary
   - Encodes a clean MP4 optimised for web/mobile
5. Preview in browser, then download

---

## Project layout

```
cutai/
├── main.py              # FastAPI server and routes
├── video_processor.py   # FFmpeg + pydub processing pipeline
├── requirements.txt
├── frontend/
│   └── index.html       # Single-page app
├── temp/                # Auto-cleaned after each job
├── uploads/             # Auto-cleaned after processing
└── outputs/             # Finished videos (delete manually)
```

---

## Deploy to the web (Railway — free)

1. Push this folder to a GitHub repo
2. Go to https://railway.app → New Project → Deploy from repo
3. It auto-detects Python and runs `python main.py`
4. You get a public URL instantly — share with anyone

---

## Troubleshooting

**"FFmpeg is not installed"**
Run `ffmpeg -version` in your terminal. If it fails, install FFmpeg first.

**Video comes back the same length**
The silence threshold may be too conservative. Move the slider towards "Aggressive" and re-run.

**Processing is slow on large files**
FFmpeg runs in real time — a 10-minute clip takes ~1-2 minutes to process.
